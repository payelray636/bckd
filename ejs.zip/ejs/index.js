const express = require("express");
const app = express();
let pass= "12345";
const methodOverride = require('method-override');
const mysql = require('mysql2');
const port = 7485;
const path = require("path");

app.use(express.urlencoded({extended:true}));
app.use(methodOverride('_method'));
app.use(express.json());

const { v4 :uuidv4 } = require('uuid');
const uniqueId = uuidv4();
console.log(uniqueId);

let cnt =[{id:1, cmnt:"nice"},
    {id:2, cmnt:"good"},
     {id:3, cmnt:"beautiful"},
     {id:4, cmnt:"well"},
     {id:5, cmnt:"amazing"}
]

app.set("view engine","ejs");
app.set("views engine", path.join(__dirname, "/views"));

app.use(express.static(path.join(__dirname, 'public')));


app.listen(port, ()=>{
    console.log("Done");
    });

    

    app.post("/img/:id", (req, res)=>{
      let {id} = req.params;
      let iid = cnt.find((i)=>i.id==id)
      res.render("id.ejs",{iid});
       });

    app.get("/",(req,res)=>{
      
        let idd=2;
        let iid = cnt.find((i)=>i.id===idd)
        console.log(iid);
        res.render("home.ejs", {iid});
    });


    app.get("/home/:id", (req, res)=>{
    let {id} = req.params;
    let ii = cnt.find((i)=>i.id==id)
    res.render("index.ejs");
    console.log(ii)
    });

    app.get("/sdata", (req, res)=>{
      let xi = cnt.find((i)=>i.id==2)
      res.render("details.ejs",{xi});

    });
    app.patch("/sdata/hi", (req, res)=>{
      let {arw} = req.body;
      let xi = cnt.find((i)=>i.id==2)
      xi.cmnt=arw;
     res.redirect("/img")
      console.log(xi);
    });

    app.delete("/sdata/hi", (req, res)=>{
      let {arw} = req.body;
      cnt = cnt.filter((i)=>i.id!==2)
      res.redirect("/img")
      console.log(cnt);
    });
                                            
      app.get("/img",(req,res)=>{
        let {id} = req.params;
        let iid = cnt.find((i)=>i.id==id)
        res.render("index.ejs",{cnt, iid});
    });
  
let users = [
    { user: "naina", pass: "##naina" },
    { user: "misti", pass: "##misti" },
    { user: "vishakha", pass: "##vishakha" },
    { user: "shreya", pass: "##shreya" },
    { user: "samriddhi", pass: "##samriddhi" },
    { user: "subhi", pass: "##subhi" }
  ];

app.post("/form",(req,res)=>{
    let{username, password}=req.body;
    let us = users.find(u => u.user === username && u.pass === password);
    if (us) {
    
    res.render("info.ejs" , {username})

      } else {
     res.send('<h1>The password is wrong .please try again.....</h1><br><button class="bt"><a href="http://localhost:7485/"><h3>Back</h3></a></button>');
      }
      console.log(req.body);
    });
   ;

app.get("/gotoform",(req,res)=>{
    res.render("form.ejs");
});

app.post("/cmnt",(req,res)=>{
   let {cmnt}=req.body;
   cnt.push({uniqueId,cmnt});
   console.log(cnt);
   console.log(uuidv4());
   res.render("index.js",{cnt});
});   

app.post("/sdata",(req, res)=>{
  let {arw}=req.body;
  let idd=2;
  let iid = cnt.find((i)=>i.id===idd)
  iid.cmnt=arw;
  res.redirect("/")
})

app.get("/home",(req,res)=>{
  res.render("others.ejs");
});

app.post("/home/good",(req,res)=>{
  res.send("hello....");
});


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'misti',
  password:'ssz123'
});

// let q= 'INSERT INTO students (id, name, age) VALUES (8, "samriddhi", 12)';

// let qq= []
// try{ connection.query(
//   q,
//   function (err, results) {
//     if (err) throw err;
    
    
//     console.log(results); 
   
//   }
// );}
// catch(err) {
//   console.log(err);
// }
app.get("/dbdata",(req,res)=>{
  res.render("dbdata.ejs");
  let q= "select * from students where id = '2'";

try{ connection.query(
  q,
  function (err, results) {
    if (err) throw err; 
    let ejdata =results;
    console.log(ejdata); 
    res.render("dbdata.ejs", {ejdata})
  }
);}
catch(err) {
  console.log(err);
}
});

app.post("/dbdata",(req,res)=>{
    let {id, name, age}=req.body;
let q= `INSERT INTO students (id, name, age) VALUES (${id}, "${name}", ${age})`;
try{ connection.query(
  q,
  function (err, results) {
    if (err) throw err; 
    console.log(results); 
res.redirect("dbdata.ejs");
  }

);}
catch(err) {
  console.log(err);
}
 
});


app.get("/contact",(req,res)=>{
  res.render("contact.ejs");

})

app.post("/contact",(req,res)=>{
      let {name, email, message}=req.body;
let m= `INSERT INTO contact (name, email, message) VALUES ("${name}", "${email}", "${message}")`;
try{ connection.query(
  m,
  function (err, results) {
    if (err) throw err; 
    console.log(results); 
res.redirect("contact");
  }

);}
catch(err) {
  console.log(err);
}
})










